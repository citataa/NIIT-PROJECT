package codes.Model;

public class Cust {

	    private int id;
	    private String userName;
	    private String email;
	    private String phone;
	    private String msg;
	 
	    public int getId() {
	        return id;
	    }
	 
	    public void setId(int id) {
	        this.id = id;
	    }
	 
	    public String getUserName() {
	        return userName;
	    }
	 
	    public void setUserName(String userName) {
	        this.userName = userName;
	    }
	 
	 
	    public String getEmail() {
	        return email;
	    }
	 
	    public void setEmail(String email) {
	        this.email = email;
	    }
	 
	    public String getPhone() {
	        return phone;
	    }
	 
	    public void setPhone(String phone) {
	        this.phone = phone;
	    }
	 
	    public String getMsg() {
	        return msg;
	    }
	 
	    public void setMsg(String msg) {
	        this.msg = msg;
	    
	    }
	 
	}

