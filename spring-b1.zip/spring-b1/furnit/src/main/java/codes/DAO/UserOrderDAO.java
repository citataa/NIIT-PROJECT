package codes.DAO;

import codes.Model.UserOrder;

public interface UserOrderDAO {

    void addUserOrder(UserOrder userOrder);

}
