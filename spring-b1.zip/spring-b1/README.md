# spring
spring proj-furniture
An E-Commerce webapplication
The project is based on spring framework.
fornt end is designed using bootstrap framework backend is taken care by hibernate.
